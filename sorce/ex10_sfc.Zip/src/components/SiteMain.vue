<template lang="">
    <div>
        메인
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="">
    
</style>