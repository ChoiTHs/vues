rules: {
    "vue/multi-word-component-names":"off";
  }
